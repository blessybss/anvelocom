<nav>
  <h3>Navigation</h3>
  
  <?php wp_nav_menu(array(
    'menu' => 'navbar',
    'container' => false,
    'depth' => 1,
   )); ?> 
</nav>
