<section id="not-found">
  <article>
    <h1>Not found</h1>
  </article>
</section>
